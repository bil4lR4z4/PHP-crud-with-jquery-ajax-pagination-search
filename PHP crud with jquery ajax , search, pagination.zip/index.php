<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AJAX CRUD</title>
</head>

	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/all.css">
	
	<style>
		a{
			text-decoration: none;
			color :white;
			background: black;
			padding: 10px 20px;
			margin-right: 5px;
			border-radius: 5px
		}
		.active{
			background: blue;
		}
	    a:hover{
			background: green;
		}
	</style>
	
<body>
	
	<div class="container">
	 <div class="row border border-4 border-dark">
		<div class="col-md-12">
			<div class="row">
			  <div class="col-md-12 bg-dark text-white text-center">
			       <h3>PHP AJAX CRUDE</h3>
			  </div>
			</div>
		  
			<div class="row my-4 justify-content-between">
			  <div class="col-md-3">
				 <input type="search" class="form-control shadow-none search" placeholder="Search.....">
			  </div>
			  <div class="col-md-6 d-flex justify-content-end">
			      <button type="button" class="btn btn-primary btn-sm shadow-none" data-bs-toggle="modal" data-bs-target="#exampleModal">Insert Records</button>
			  </div>
			</div>
		   
			<div class="row">
			  <div class="col-md-12">
				<table class="table table-bordered text-center">
			       <thead class="table-dark">
				      <tr class="">
					    <th>S_No</th>
					    <th>IMAGE</th>
					    <th>NAME</th>
					    <th>CITY</th>
					    <th>ACTION</th>
				      </tr>
			      </thead>
			      <tbody id="show">
				
			      </tbody>
		        </table>
			 </div>
		   </div>
		   <div class="row my-3">
			 
		   </div>
		 </div>
	   </div>
	</div>

	
	
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">INSERT MODAL</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="form" enctype="multipart/form-data" class="form">
			<div class="nammsg">
			  <label for="name" class="fw-bold">NAME</label>
		      <input type="text" class="form-control shadow-none name" id="name" name="name">
			</div>
		    <div class="citymsg">
			  <label for="city" class="fw-bold mt-3">CITY</label>
		      <input type="text" class="form-control shadow-none city" id="city" name="city">
			</div>
		    <div class="imgmsg">
			  <label for="image" class="fw-bold mt-3">IMAGE</label>
		      <input type="file" class="form-control shadow-none image" id="image" name="image">
		    </div>
		  
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm shadow-none" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-sm shadow-none save">Save Data</button>
      </div>
    </div>
  </div>
</div>
	
<!-- Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">EDIT MODAL</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="editform" enctype="multipart/form-data" class="editform">
		  
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm shadow-none" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-sm shadow-none update">Save Data</button>
      </div>
    </div>
  </div>
</div>
	
	
	<script src="js/bootstrap.js"></script>
	<script src="js/jquery.js"></script>
	<script>
	$(document).ready(function(){
		$(".name , .city , .image").on("input", function(){
			$(".text-danger").html("");
		})
		
		function loadTable(page){
		  $.ajax({
			url : "php/php_code.php?show=1",
			type : "POST",
			data : {page_no : page},
			success: function(data){
			   $("#show").html(data);
			}
		  })
		}
		loadTable();
		
		$(document).on("click", ".pagination a", function(e){
			e.preventDefault();
			
			var page_id = $(this).attr("id");
			loadTable(page_id);
		})
		
		$(".save").on("click", function(e){
			e.preventDefault();
			
			var name = $(".name").val(); 
			var city = $(".city").val();
			var image = $(".image").val();
			
			$(".text-danger").html("");
			
			if(name == ""){
			  $(".nammsg").append("<span class='text-danger'>Please Enter Name.</span>")
			}else if(city == ""){
			  $(".citymsg").append("<span class='text-danger'>Please Enter City.</span>")
		    }else if(image == ""){
			  $(".imgmsg").append("<span class='text-danger'>Please Select Image.</span>")
		    }else{
				$.ajax({
			      url : "php/php_code.php?insert=2",
			      type : "POST",
			      contentType : false,
			      processData: false,
			      data: new FormData(document.getElementById("form")),
			      success: function(data){
				    alert("Data Insert Success.");
				    $(".form").trigger("reset");
			        loadTable();
			      }
		        })
			}
		})
		
		$(document).on("click", ".delete", function(){
			var id = $(this).data("id");
			
			$.ajax({
			  url : "php/php_code.php?delete=3",
			  type : "POST",
			  data: {id:id},
			  success: function(data){
				alert("Data Delete Success.");
			    loadTable();
				  
			  }
		    })
		})
		
		$(document).on("click", ".edit", function(){
			var id = $(this).data("id");
			
			$.ajax({
			  url : "php/php_code.php?edit=4",
			  type : "POST",
			  data: {id:id},
			  success: function(data){
				$(".editform").html(data);
			    loadTable();
			  }
		    })
		})
		
		$(document).on("click", ".update", function(){
			$.ajax({
			  url : "php/php_code.php?update=5",
			  type : "POST",
			  contentType : false,
			  processData : false,
			  data: new FormData(document.getElementById("editform")),
			  success: function(data){
				alert("Data Update Success.");
			    loadTable();
				  
			  }
			})
		})
		
		$(".search").on("keyup", function(){
			var search = $(this).val();
			$.ajax({
				url : "php/php_code.php?searchData=6",
				type : "POST",
				data : {search:search},
				success : function(data){
				  $("#show").html(data);
				  //loadTable();
				}
			})
		})
	})
	</script>
</body>
</html>