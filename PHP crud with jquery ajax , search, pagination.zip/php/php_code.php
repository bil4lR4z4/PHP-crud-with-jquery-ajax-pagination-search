<?php
include('config.php');

require('../fpdf/fpdf.php');

if(isset($_GET['show']) OR isset($_GET['searchData'])){
	
	$limit_per_page = 5;
	
	$page = "";
		if(isset($_POST['page_no'])){
			$page = $_POST['page_no'];
		}else{
			$page = 1;
		}
	
	$offset = ($page-1)*$limit_per_page;
	
	$sql = mysqli_query($conn, "SELECT * FROM `data` LIMIT {$offset},{$limit_per_page}");
	if(isset($_GET['searchData'])){
		$search = mysqli_real_escape_string($conn, $_POST['search']);
	    $sql = mysqli_query($conn, "SELECT * FROM `data` WHERE `name` LIKE '%$search%' OR `city` LIKE '%$search%'");
	}
	  $output ="";
	  if(mysqli_num_rows($sql)>0){
		 $no = ($page - 1) * $limit_per_page + 1;
		  while($row = mysqli_fetch_assoc($sql)){
			  $output.= "
			       <tr>
					  <th>{$no}</th>
					  <td><img src='image/{$row['image']}' class='rounded-circle' width='50px' height='50px'></td>
					  <td>{$row['name']}</td>
					  <td>{$row['city']}</td>
					  <td>
					    <button class='btn btn-sm btn-outline-danger delete' data-id='{$row['id']}'><i class='fa-solid fa-trash'></i></button>
						<button class='btn btn-sm btn-outline-success edit' data-id='{$row['id']}' data-bs-toggle='modal' data-bs-target='#editModal' ><i class='fa-solid fa-pen-to-square'></i></button>
					  </td>
				   </tr>
			       ";
			  $no++;
		  }
		  
		  $sql_total = mysqli_query($conn, "SELECT * FROM `data`");
		  $record = mysqli_num_rows($sql_total);
		  $total_page= ceil($record/$limit_per_page);
		  
		  $output .="
		             <tr>
					 <td colspan='5'>
		              <div class='col-md-12 d-flex justify-content-center'>
				       <div class='pagination'>
		           ";
		  
		  for($i=1; $i<=$total_page; $i++){
			  $active = ($i == $page ? 'active' : '');
			  $output .= " <a href='' class='$active' id='{$i}'>{$i}</a>";
		  }
		  
		  $output .="
				       </div>
			         </div>
					 </td>
					 </tr>
		            ";
		  
		  echo  $output;
		  
	  }else{
		  echo "<tr><td colspan='5'><h4 class='text-center'>Data Not Found.</h4></td></tr>";
	  }
  }

if(isset($_GET['insert'])){
	$name =  mysqli_real_escape_string($conn, $_POST['name']);
	$city =  mysqli_real_escape_string($conn, $_POST['city']);
	
	$image = $_FILES['image']['name'];
	$tmpName = $_FILES['image']['tmp_name'];
	$baseName = time().'_'.basename($image);
	$folder = "../image/". $baseName;
	move_uploaded_file($tmpName, $folder);
	
	$sql = mysqli_query($conn, "INSERT INTO `data`(`name`, `city`, `image`) VALUES ('$name','$city','$baseName')");
	
	if($sql){
		echo "Insert";
	}else{
		echo "Not Insert" . mysqli_error($conn);
	}
}

if(isset($_GET['delete'])){
	$id = $_POST['id'];
	
	$select = mysqli_query($conn, "SELECT * FROM `data` WHERE id={$id}");
	$row = mysqli_fetch_assoc($select);
	unlink("../image/".$row['image']);
	
	$sql = mysqli_query($conn, "DELETE FROM `data` WHERE `id` = {$id}");
	if($sql){
		echo "Delete";
	}else{
		echo "Not Delete" . mysqli_error($conn);
	}
}

if(isset($_GET['edit'])){
	$id = $_POST['id'];
	$sql = mysqli_query($conn, "SELECT * FROM `data` WHERE `id` = {$id}");
	
	while($row = mysqli_fetch_assoc($sql)){
		echo "
		     <input type='hidden' value='{$row['id']}' name='uid'>
			 <input type='hidden' value='{$row['image']}' name='imgname'>
		     <label for='uname' class='fw-bold'>NAME</label>
		     <input type='text' class='form-control shadow-none' id='uname' name='uname' value='{$row['name']}'>
		     <label for='ucity' class='fw-bold mt-3'>CITY</label>
		     <input type='text' class='form-control shadow-none' id='ucity' name='ucity' value='{$row['city']}'>
		     <label for='uimage' class='fw-bold mt-3'>IMAGE</label>
		     <input type='file' class='form-control shadow-none' id='uimage' name='uimage'>
		     ";
	}
	
}

if(isset($_GET['update'])){
	$uid = $_POST['uid'];
	
	$uname = mysqli_real_escape_string($conn, $_POST['uname']);
	$ucity = mysqli_real_escape_string($conn, $_POST['ucity']);
	
	$image = $_POST['imgname'];
	if(isset($_FILES['uimage']) && $_FILES['uimage']['name']){
		$image = $_FILES['uimage']['name'];
		$tmpName = $_FILES['uimage']['tmp_name'];
		$baseName = time() .'_'. basename($image);
		$folder = "../image/". $baseName;
	    move_uploaded_file($tmpName, $folder);
		
		$select = mysqli_query($conn, "SELECT * FROM `data` WHERE `id`={$uid} ");
	    $row = mysqli_fetch_assoc($select);
	    unlink("../image/".$row['image']);
	}
	
	$sql = mysqli_query($conn, "UPDATE `data` SET `name`='$uname',`city`='$ucity',`image`='$baseName' WHERE `id`={$uid}");
	if($sql){
		echo "Update";
	}else{
		echo "Not Update" . mysqli_error($conn);
	}
	
}

if(isset($_GET['pdf'])){
	
	
}
?>