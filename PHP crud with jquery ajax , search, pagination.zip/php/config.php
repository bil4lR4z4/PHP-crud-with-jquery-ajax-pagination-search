<?php
  $host = "Localhost";
  $username = "root";
  $password = "";
  $db = "crud";
  $conn = new mysqli($host, $username, $password, $db);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }